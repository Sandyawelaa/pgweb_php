<!DOCTYPE html>
<html>
    <body>

    <?php
    $x = 2;
    $y = "belinda";

    echo $x;
    echo "<br>";
    echo $y;
    ?>

</body>
</html>