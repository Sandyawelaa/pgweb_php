<!DOCTYPE html>
<html>
    <body>

    <?php
   $color = array("red", "green", "blue");
   echo $color[2];
    ?>

</body>
</html>