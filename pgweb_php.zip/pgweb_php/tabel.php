<!DOCTYPE html>
<html>
    <body>

    <?php
   $colors = array("COLORS", "black", "white", "grey");
   $foods = array("FOODS", "soto", "mie", "bakso");
   
   echo "<table border='1'>";
   for($i=0; $i <= 3; $i++) {
    echo "<tr><td> $colors[$i] </td><td> $foods[$i] </td><tr>"
   }
   

   echo "</table>";
    ?>

</body>
</html>