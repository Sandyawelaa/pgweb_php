<!DOCTYPE html>
<html>
    <body>

    <?php
    $txt = "Belinda";
    echo "Halo Aku " . $txt . "!";
    ?>

</body>
</html>