<!DOCTYPE html>
<html>
    <body>

    <?php
    $x = "Sandyawela";
    echo "Hello $x";
    ?>

</body>
</html>