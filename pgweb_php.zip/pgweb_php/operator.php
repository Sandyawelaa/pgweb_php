<!DOCTYPE html>
<html>
    <body>

    <?php
    $t = 10;

    if ($t < 20) {
    echo "Nilai Benar";
    }
    else {
    echo "Nilai Salah";
    }
    ?>

</body>
</html>