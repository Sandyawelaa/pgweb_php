<!DOCTYPE html>
<html>
    <body>

    <?php
   function familyName($fname, $year) {
    echo "$fname Atashah. Born in $year <br>";
   }
   familyName("Farel", "2005");
   familyName("Belinda", "2004");
   familyName("Shaka", "2005");
    ?>

</body>
</html>