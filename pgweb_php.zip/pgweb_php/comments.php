<!DOCTYPE html>
<html>
    <body>

    <?php
    //This is a single-line coment

    # This is also a single-line coment
    
    /* This is
    multi-line coment */
    ?>

</body>
</html>