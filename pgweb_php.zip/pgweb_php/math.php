<!DOCTYPE html>
<html>
    <body>

    <?php
   echo(min(0, 180, 60, 40, -10, -230));
   echo(max(0, 120, 40, 20, -8, -180));
    ?>

</body>
</html>