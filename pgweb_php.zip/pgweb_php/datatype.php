<!DOCTYPE html>
<html>
    <body>

    <?php
    $x = "Halo";
    $y = 'Belinda!';
    
    var_dump($x);
    echo "<br>";
    var_dump($y);
    ?>

</body>
</html>