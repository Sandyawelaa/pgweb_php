<!DOCTYPE html>
<html>
    <body>

    <?php
    $a = 10;
    $b = 10.10;
    $c = "100";

    var_dump($a);
    var_dump($b);
    var_dump($c);
    ?>

</body>
</html>