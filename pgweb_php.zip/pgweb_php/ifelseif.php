<!DOCTYPE html>
<html>
    <body>

    <?php
    $t = 11;

    if ($t < 20) {
      echo "Have a good day, baby!";
    }
    
    ?>

</body>
</html>