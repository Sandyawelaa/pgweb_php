<!DOCTYPE html>
<html>
    <body>

    <?php
   for ($x = 0; $x <= 15; $x++) {
    echo "The number is: $x <br>";
   }
    ?>

</body>
</html>